import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.racelearn.game',
  appName: 'مسابقه و یادگیری',
  webDir: 'www',
  android: {
    backgroundColor: '#07111d'
  }
};

export default config;
